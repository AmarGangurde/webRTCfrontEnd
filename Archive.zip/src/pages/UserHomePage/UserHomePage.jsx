import React from 'react';
import Navigation2 from '../../component/Navigation2';
import Pagenumber from '../../component/Pagenumber';
import Container from '../../component/Container';
import Switch from '../../component/Switch';
import Select from '../../component/Select';
import { Button } from '@mui/material';
import { BrowserRouter as Router } from 'react-router-dom';


function UserHomePage() {

  return (
    <div>
        <Navigation2/><br></br>
      <div style={{ paddingLeft: 670, position: 'relative' }}>
        <div style={{ position: 'absolute' }}>
          <Select />
        </div>
      </div>
      <Container/><br></br>
      <Container/>
      <Button>Hello</Button>
      <Switch/>
     <Pagenumber/> 
    </div>

    
  );
}

export default UserHomePage;
