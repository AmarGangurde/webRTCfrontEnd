
import * as React from 'react';
import Button from '@mui/material/Button';

function AboutPage() {

    return (
      <div>
        <Button variant="contained">Hello world</Button>     
      </div>
    )
  }

  export default AboutPage