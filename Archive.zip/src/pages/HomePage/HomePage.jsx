
import Pricing from '../../component/Pricing'




function HomePage() {

  return (
        <div>
          <Pricing></Pricing>
        </div>
     
  )
}

export default HomePage
