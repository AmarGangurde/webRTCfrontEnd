
import SignUp from "../../component/SignUp"

function NewSignUp() {

  return (
        <div>
          <SignUp/>
        </div>
     
  )
}

export default NewSignUp
