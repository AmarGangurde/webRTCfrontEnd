

function BuyPage(){
    
    
    return(
        <h1>This is BuYPage</h1>
    )
}