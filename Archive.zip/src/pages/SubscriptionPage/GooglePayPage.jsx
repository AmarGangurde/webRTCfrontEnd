import GoogleApi from '../../component/GoogleApi'


function GooglePayPage(){
    
    return(
        <div>
            <h1>Pay Using Gpay</h1>
           <GoogleApi/>
        </div>       
    )
}

export default GooglePayPage;