
import SignIn from "../../component/SignIn"

function NewSignIn() {
  return (
        <div>
          <SignIn/>
        </div>
     
  )
}

export default NewSignIn
