import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Button from '@mui/material/Button';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Link from '@mui/material/Link';
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';
import { IconButton } from '@mui/material';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';

const settings = ['Profile', 'Dashboard', 'LogOut'];

function Navigation(){

  const[anchorUser,setAnchorUser]=React.useState(null);

  const openUserMenu=(event)=>{
    setAnchorUser(event.currentTarget)
  }
  const closeUserMenu=()=>{
    setAnchorUser(null)
  }

  const opneNav=()=>{
    console.log("hello")
  }

    return(

      <AppBar
        position="static"
        color="default"
        elevation={0}
        sx={{ borderBottom: (theme) => `1px solid ${theme.palette.divider}` }}
      >
        <Toolbar sx={{ flexWrap: 'wrap' }}>
          <Typography variant="h6" color="inherit" noWrap sx={{ flexGrow: 1 }}>
            S2P
          </Typography>
          <nav>
            <Link
              variant="button"
              color="text.primary"
              href="#"
              sx={{ my: 1, mx: 1.5 }}
            >
              Home
            </Link>
            <Link
              variant="button"
              color="text.primary"
              href="#"
              sx={{ my: 1, mx: 1.5 }}
            >
              Pricing
            </Link>
            <Link
              variant="button"
              color="text.primary"
              href="#"
              sx={{ my: 1, mx: 1.5 }}
            >
              Support
            </Link>
          </nav>
          <Stack direction="row" spacing={2}>
      <IconButton onClick={openUserMenu}>
        <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" />
      </IconButton>
      <Menu
        id="user-menu"
        anchorEl={anchorUser}
        open={Boolean(anchorUser)}
        onClose={closeUserMenu}
      >
        {settings.map((setting) => (
          <MenuItem key={setting} onClick={closeUserMenu}>
            <Typography>
              {setting}
            </Typography>
          </MenuItem>
        ))}
      </Menu>
    </Stack>
           
        </Toolbar>
      </AppBar>

    )
}

export default Navigation