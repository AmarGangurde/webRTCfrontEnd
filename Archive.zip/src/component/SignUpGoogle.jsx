import { useEffect, useState } from "react";
import { jwtDecode } from 'jwt-decode';
import { useNavigate, useLocation } from "react-router-dom";

function SignUpGoogle() {
  const [user, setUser] = useState({});
  const location = useLocation();
  const navigate = useNavigate();

  function handleCallbackResponse(response) {
    console.log("Encoded JWT ID token " + response.credential);
    var userObject = jwtDecode(response.credential);
    console.log(userObject);
    setUser(userObject);
    document.getElementById("signinDiv").hidden = true;
  }

  function handleSignOut() {
    setUser({});
    document.getElementById("signinDiv").hidden = false;
  }

  const goToUserHome = () => {
    navigate('/UserHomePage', { state: {user: user } });
  };
  

  useEffect(() => {
    /* Global Google From index.html */
    google.accounts.id.initialize({
      client_id: "57700588816-adotfaoq3r96dvukkqejkic6l4jn5o11.apps.googleusercontent.com",
      callback: handleCallbackResponse
    });

    google.accounts.id.renderButton(
      document.getElementById("signinDiv"),
      { theme: "outline", size: "large" }
    );
  }, []);

  return (
    <div>
      <div id="signinDiv"></div>
      {(location.pathname === "/UserHomePage" || Object.keys(user).length !== 0) && (
        <div>
          <img src={user.picture} alt="User" />
          <h2>{user.name}</h2>
        </div>
      )}
      

      {Object.keys(user).length !== 0 && (
        <>
          <button onClick={handleSignOut}>Sign Out</button>
          <button onClick={goToUserHome}>User Home</button>
        </>
      )}
    </div>
  );
}

export default SignUpGoogle;
