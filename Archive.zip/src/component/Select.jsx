import React, { useState } from 'react';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';


export default function SelectLabels({ numberOfCameras }) {
  const [selectedCamera, setSelectedCamera] = React.useState('');

  const handleChange = (event) => {
    setSelectedCamera(event.target.value);
  };

  // Generate an array of camera numbers based on the prop value
  const cameraNumbers = Array.from({ length: numberOfCameras }, (_, index) => index + 1);


  return (
    <div>
      <FormControl sx={{ m: 1, minWidth: 120 }}>
        <Select
          value={selectedCamera}
          onChange={handleChange}
          displayEmpty
          inputProps={{ 'aria-label': 'Without label' }}
        >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          {cameraNumbers.map((cameraNumber) => (
            <MenuItem key={cameraNumber} value={cameraNumber}>
              Camera {cameraNumber}
            </MenuItem>
          ))}
        </Select>
        <FormHelperText>Select Your Camera</FormHelperText>
      </FormControl>
    </div>
  );
}
