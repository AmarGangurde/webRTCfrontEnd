import * as React from 'react';
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import { Padding } from '@mui/icons-material';

export default function SimpleContainer() {
  const videoWidth = 640; // Set your video width
  const videoHeight = 360; // Set your video height

  return (
    <React.Fragment>
      <CssBaseline />
      <Container maxWidth="false" disableGutters sx={{paddingLeft:2.5}}>
        <Box
          sx={{
            bgcolor: '#cfe8fc',
            width: videoWidth,
            height: videoHeight,
            position: 'relative',
            overflow: 'hidden',
          }}
        >
          <video
            style={{ width: '100%', height: '100%', position: 'absolute', top: 0, left: 0 }}
            controls
          >
            <source src="your-video-file.mp4" type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        </Box>
      </Container>
    </React.Fragment>
  );
}
