import HomePage from './pages/HomePage/HomePage';
import SignUpGoogle from './component/SignUpGoogle';
import UserHomePage from './pages/UserHomePage/UserHomePage';
import SubscriptionPage from './pages/SubscriptionPage/SubScriptionPage';
import AfterSubscription from './pages/AfterSubscription/AfterSubscription';
import GooglePayPage from './pages/SubscriptionPage/GooglePayPage';
import NewSignUp from './pages/NewSignUp/NewSignUp';
import NewSignIn from './pages/NewSignInPage/NewSignIn';
import { Route,Routes } from 'react-router-dom';
import Darkmode from './component/Darkmode'
import { CssBaseline } from '@mui/material';





function App(){

    return(
            <Routes>
                <Route path='/' element={<HomePage/>}/>
                <Route path='/NewSignIn' element={<NewSignIn/>}/>
                <Route path='/NewSignUp' element={<NewSignUp/>}/>
                <Route path='/SignUpGoogle' element={<SignUpGoogle/>}/>
                <Route path='/UserHomePage' element={<UserHomePage/>}/>
                <Route path='/SubscriptionPage' element={<SubscriptionPage/>}/>
                <Route path='/AfterSubscription' element={<AfterSubscription/>}></Route>
                <Route path='/GooglePayPage' element={<GooglePayPage/>}></Route>
            </Routes>      
    )
    
}
export default App;