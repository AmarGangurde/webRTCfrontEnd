import Prices from '../../component/Prices'
import { useState } from 'react'
import Navbar from "../../component/Navbar"

function PaymentPage() {

  const [count,setCount] = useState(0)

  function decreased(){
    setCount (count=>count-1)
  }
  function increased(){
    setCount (preveCount=>preveCount+1)
  }


    return (
        <div id='root'>
          <Navbar></Navbar>
          <Prices name="Basic" price={`${30}$`} date={`${30} Days`}/>
          <Prices name="Advanced" price={`${40}$`} date={`${30} Days`}/>
          <Prices name="Pro" price={`${50}$`} date={`${50} Days`}/>
          <button onClick={decreased}>-</button>
          <span>{count}</span>
          <button onClick={increased}>+</button>
        </div>
    )
  }
  
  export default PaymentPage