import VideoCard2 from "../../component/VideoCard2"



function AfterSubscription(){

    
    
    return( 
        <div>
            <VideoCard2 ip={` rtsp:\\example\\192.234 `}/>
            <VideoCard2 ip={` rtsp:\\example\\192.234 `}/>
            <VideoCard2 ip={` rtsp:\\example\\192.234 `}/>
            <VideoCard2 ip={` rtsp:\\example\\192.234 `}/>
        </div>
    )
}
console.log("hello")
export default AfterSubscription