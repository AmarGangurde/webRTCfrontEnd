import Prices from "../../component/Prices"
import VideoCard from "../../component/VideoCard"
import Navbar from "../../component/Navbar"
import * as React from 'react';
import Button from '@mui/material/Button';

function AboutPage() {

    return (
      <div>
        <Navbar></Navbar>
            <VideoCard ip={`rtspIP:example://`}/>
            <VideoCard ip={`rtspIP:example://`}/>
            <VideoCard ip={`rtspIP:example://`}/>
            <VideoCard ip={`rtspIP:example://`}/>
            <Button variant="contained">Hello world</Button>
            
      </div>
    )
  }
  
  export default AboutPage