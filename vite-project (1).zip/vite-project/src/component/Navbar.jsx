import './navbar.css';

export default function Navbar(){
    return(
        <nav className="nav">
            <a className="mainFont">S2P</a>
            <ul>
                <li>
                    <a href="/">Home</a>
                 </li>
                <li>
                    <a href="/PricesPage">Pricing</a>
                 </li>
                 <li>
                    <a href="/AboutPage">About</a>
                 </li>
                 <li>
                    <a href="/SignupPage">Sign Up</a>
                 </li>
                 
            </ul>
        </nav>
    )
}