import image from '../assets/pc1.jpg'
import './card.css'

const VideoCard=(props)=>{

    return(
     <div className="videoCard">
        <img src={image} width={'200px'} alt='profile-pciture'></img>
        <input id='ipInput' type='text' maxLength='30' size={`10`}></input>
        <button id='ipSubmitBtn'>submit</button>
     </div>
 )
}

export default VideoCard