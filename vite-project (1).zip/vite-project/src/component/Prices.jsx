import './card.css'


function Prices(props){
    return(
        <div className='cardPrice'>
            <p>Type: {props.name}</p>
            <p>Price: {props.price}</p>
            <p>Validity: {props.date}</p>
        </div>
    )
}

export default Prices