import HomePage from './pages/HomePage/HomePage';
import PricesPage from './pages/PricesPage/PricesPage';
import SignupPage from './pages/SignupPage/SignupPage';
import AboutPage from './pages/AboutPage/AboutPage';
import UserHomePage from './pages/UserHomePage/UserHomePage';
import SubscriptionPage from './pages/SubscriptionPage/SubScriptionPage';
import AfterSubscription from './pages/AfterSubscription/AfterSubscription';
import { Route,Routes } from 'react-router-dom';



function App(){
    return(
        <>
           <div>
            <Routes>
                <Route path='/' element={<HomePage/>}/>
                <Route path='/PricesPage' element={<PricesPage/>}/>
                <Route path='/SignupPage' element={<SignupPage/>}/>
                <Route path='/AboutPage' element={<AboutPage/>}/>
                <Route path='/UserHomePage' element={<UserHomePage/>}/>
                <Route path='/SubscriptionPage' element={<SubscriptionPage/>}/>
                <Route path='/AfterSubscription' element={<AfterSubscription/>}></Route>
            </Routes>
           </div>
        </>
    )
    
}
export default App;