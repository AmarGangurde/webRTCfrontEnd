import image from '../assets/pc1.jpg'
import './card.css'

const VideoCard=(props)=>{
    return(
        <div className="videoCard">
        <img src={image} width={'200px'} alt='profile-pciture'></img>
        <p>webRTC ID:</p>
    </div>
 )
}

export default VideoCard