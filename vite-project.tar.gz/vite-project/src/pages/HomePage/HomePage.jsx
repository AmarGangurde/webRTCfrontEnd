
import './homePage.css'
import Counter from '../../component/Counter'
import Navbar from "../../component/Navbar"


function HomePage() {

  return (
        <div>
          <Navbar></Navbar>
             <h1>Welcome</h1>
             <h2>WebRTC For You Organization Servelance System</h2>
             <p>Nice</p>
            <Counter/>
        </div>
     
  )
}

export default HomePage
