import { useNavigate } from "react-router-dom"


 

function UserHomePage() {

  const navigate = useNavigate();

  function Buy(){ 
    navigate('/SubscriptionPage')
  } 

    return (
        <div id='root'>
       
          <h1>hello</h1>
          <p>SignUpPage</p>
          <button onClick={Buy}>Buy 30$ subscription</button>
         
        </div>
    )
  }
  
  export default UserHomePage