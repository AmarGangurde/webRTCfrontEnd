import Prices from "../../component/Prices"
import VideoCard from "../../component/VideoCard"
import Navbar from "../../component/Navbar"

function AboutPage() {

    return (
      <div>
        <Navbar></Navbar>
            <VideoCard/>
            <VideoCard/>
            <VideoCard/>
            <VideoCard/>
      </div>
    )
  }
  
  export default AboutPage